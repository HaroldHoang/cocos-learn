System.register(["__unresolved_0", "cc", "__unresolved_1", "__unresolved_2"], function (_export, _context) {
  "use strict";

  var _reporterNs, _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, screen, Label, Button, sp, Canvas, Camera, view, ResolutionPolicy, FullScreenManager, RotateManager, _dec, _dec2, _dec3, _dec4, _dec5, _dec6, _dec7, _dec8, _dec9, _class, _class2, _descriptor, _descriptor2, _descriptor3, _descriptor4, _descriptor5, _descriptor6, _descriptor7, _descriptor8, _crd, ccclass, property, HomeController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  function _reportPossibleCrUseOfFullScreenManager(extras) {
    _reporterNs.report("FullScreenManager", "../singleton/ScreenManager", _context.meta, extras);
  }

  function _reportPossibleCrUseOfRotateManager(extras) {
    _reporterNs.report("RotateManager", "../singleton/ScreenManager", _context.meta, extras);
  }

  return {
    setters: [function (_unresolved_) {
      _reporterNs = _unresolved_;
    }, function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      screen = _cc.screen;
      Label = _cc.Label;
      Button = _cc.Button;
      sp = _cc.sp;
      Canvas = _cc.Canvas;
      Camera = _cc.Camera;
      view = _cc.view;
      ResolutionPolicy = _cc.ResolutionPolicy;
    }, function (_unresolved_2) {
      FullScreenManager = _unresolved_2.FullScreenManager;
    }, function (_unresolved_3) {
      RotateManager = _unresolved_3.RotateManager;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "7895eRnplVC+735ba4UHA4V", "HomeController", undefined);

      __checkObsolete__(['_decorator', 'Component', 'screen', 'Label', 'Button', 'sp', 'Canvas', 'Camera', 'renderer', 'view', 'ResolutionPolicy']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("HomeController", HomeController = (_dec = ccclass("HomeController"), _dec2 = property(sp.Skeleton), _dec3 = property(Label), _dec4 = property(Button), _dec5 = property(Label), _dec6 = property(Button), _dec7 = property(Label), _dec8 = property(Canvas), _dec9 = property(Camera), _dec(_class = (_class2 = class HomeController extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "monter", _descriptor, this);

          _initializerDefineProperty(this, "lblInstruction", _descriptor2, this);

          _initializerDefineProperty(this, "btnFullScreen", _descriptor3, this);

          _initializerDefineProperty(this, "lblBtnFullScreen", _descriptor4, this);

          _initializerDefineProperty(this, "btnRotate", _descriptor5, this);

          _initializerDefineProperty(this, "lblBtnRotate", _descriptor6, this);

          _initializerDefineProperty(this, "canvas", _descriptor7, this);

          _initializerDefineProperty(this, "camera", _descriptor8, this);

          this.isFullScreen = false;
          this.fullScreenManager = (_crd && FullScreenManager === void 0 ? (_reportPossibleCrUseOfFullScreenManager({
            error: Error()
          }), FullScreenManager) : FullScreenManager).getInstance();
          this.rotateManager = (_crd && RotateManager === void 0 ? (_reportPossibleCrUseOfRotateManager({
            error: Error()
          }), RotateManager) : RotateManager).getInstance();
          this.isHorizontal = true;
          this.designResolution = view.getDesignResolutionSize();
          this.fovDefault = void 0;

          this.changeStateScreen = () => this.fullScreenManager.toggleFullScreen();
        }

        onLoad() {
          this.btnFullScreen.node.on(Button.EventType.CLICK, this.changeStateScreen, this);
          this.btnRotate.node.on(Button.EventType.CLICK, this.changeRotation, this);
          screen.on("fullscreen-change", this.handleFullScreen, this);
        }

        handleFullScreen() {
          this.isFullScreen = !this.isFullScreen;
          this.lblBtnFullScreen.string = this.isFullScreen ? "Exit" : "Full Screen";
        }

        changeRotation() {
          if (this.isHorizontal) {
            view.setDesignResolutionSize(600, 900, ResolutionPolicy.SHOW_ALL);
            this.rotateManager.onVertical();
            this.monter.node.setPosition(-500, -50);
            this.btnFullScreen.node.setPosition(-150, 400, 0);
            this.btnRotate.node.setPosition(-270, 400, 0);
            this.lblInstruction.string = "U: attack1       I: attack2\nO: attack3       P: get-hit        Space: die\ndefault: idle";
            this.lblInstruction.lineHeight = 50;
            this.lblInstruction.node.setPosition(-420, -300, 0);
            this.isHorizontal = false;
          } else {
            view.setDesignResolutionSize(this.designResolution.width, this.designResolution.height, ResolutionPolicy.SHOW_ALL);
            this.rotateManager.onHorizontal();
            this.monter.node.setPosition(-36, -110);
            this.btnFullScreen.node.setPosition(566, 310, 0);
            this.btnRotate.node.setPosition(442, 310, 0);
            this.lblInstruction.string = "U: attack1      I: attack2      O: attack3      P: get-hit      Space: die\ndefault: idle";
            this.lblInstruction.lineHeight = 50;
            this.lblInstruction.node.setPosition(-16, -260, 0);
            this.isHorizontal = true;
          }
        }

        onDestroy() {
          this.btnFullScreen.node.off(Button.EventType.CLICK, this.changeStateScreen, this);
          this.btnRotate.node.off(Button.EventType.CLICK, this.changeRotation, this);
          screen.off("fullscreen-change", this.handleFullScreen, this);
        }

        update() {}

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "monter", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor2 = _applyDecoratedDescriptor(_class2.prototype, "lblInstruction", [_dec3], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor3 = _applyDecoratedDescriptor(_class2.prototype, "btnFullScreen", [_dec4], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor4 = _applyDecoratedDescriptor(_class2.prototype, "lblBtnFullScreen", [_dec5], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor5 = _applyDecoratedDescriptor(_class2.prototype, "btnRotate", [_dec6], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor6 = _applyDecoratedDescriptor(_class2.prototype, "lblBtnRotate", [_dec7], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor7 = _applyDecoratedDescriptor(_class2.prototype, "canvas", [_dec8], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      }), _descriptor8 = _applyDecoratedDescriptor(_class2.prototype, "camera", [_dec9], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=521e43fc3f0cc2363a6220f78f8b50398438aeeb.js.map
System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, FullScreenManager, RotateManager, _crd;

  _export({
    FullScreenManager: void 0,
    RotateManager: void 0
  });

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "1b6f3KSiHlIk7qOj9UhLKUn", "ScreenManager", undefined);

      _export("FullScreenManager", FullScreenManager = class FullScreenManager {
        static getInstance() {
          return this._instance === null ? new FullScreenManager() : this._instance;
        }

        toggleFullScreen() {
          if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(err => {
              console.error("Error attempting to enable fullscreen mode:", err);
            });
          } else {
            document.exitFullscreen().catch(err => {
              console.error("Error attempting to exit fullscreen mode:", err);
            });
          }
        }

      });

      FullScreenManager._instance = null;

      _export("RotateManager", RotateManager = class RotateManager {
        static getInstance() {
          if (this._instance === null) {
            this._instance = new RotateManager();
          }

          return this._instance;
        }

        onHorizontal() {
          if (!document.fullscreenElement) {
            var gameDiv = document.getElementById("GameDiv");
            var game = document.getElementById("GameCanvas");
            gameDiv.setAttribute("style", "display: flex;justify-content: center;align-items: center;width: 1280px;height: 720px;");
            game.setAttribute("height", "720");
            game.setAttribute("width", "1280");
          }
        }

        onVertical() {
          if (!document.fullscreenElement) {
            var gameDiv = document.getElementById("GameDiv");
            var game = document.getElementById("GameCanvas");
            var width = window.innerWidth;
            gameDiv.setAttribute("style", "display: flex;justify-content: center;align-items: center;width: 600px;height: 900px;");
            game.setAttribute("width", "600px");
            game.setAttribute("height", "900px");
          }
        }

      });

      RotateManager._instance = null;

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=ad27125108bf0faca8a9dcb8d7108fc794f3d43b.js.map
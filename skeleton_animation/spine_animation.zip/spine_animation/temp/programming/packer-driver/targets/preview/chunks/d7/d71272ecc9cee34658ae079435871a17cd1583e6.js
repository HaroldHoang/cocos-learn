System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/User/Desktop/cocos_project/skeleton_animation/spine_animation/assets/scripts/HomeController.ts at runtime.
      throw new Error("SyntaxError: C:CocosDashboard_2.1.4\file:C:UsersUserDesktopcocos_projectskeleton_animationspine_animationassetsscriptsHomeController.ts: Unexpected token (48:1)\n\n  46 | \t\tconst fullScreen = \n  47 |\n> 48 | \t}\n     | \t^\n  49 |\n  50 | \tonRotate(){\n  51 |");
    }
  };
});
//# sourceMappingURL=d71272ecc9cee34658ae079435871a17cd1583e6.js.map
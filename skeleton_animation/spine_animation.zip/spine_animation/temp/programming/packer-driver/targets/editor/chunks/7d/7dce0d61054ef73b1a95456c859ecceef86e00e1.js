System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/User/Desktop/cocos_project/skeleton_animation/spine_animation/assets/scripts/HomeController.ts at runtime.
      throw new Error(`SyntaxError: C:\CocosDashboard_2.1.4\file:\C:\Users\User\Desktop\cocos_project\skeleton_animation\spine_animation\assets\scripts\HomeController.ts: Identifier 'Monter' has already been declared. (46:8)

  44 | 		const Monter = this.node.getChildByName("Monter");
  45 | 		const ButtonFullscreen = this.node.getChildByName("Monter");
> 46 | 		const Monter = this.node.getChildByName("Monter");
     | 		      ^
  47 | 		const Monter = this.node.getChildByName("Monter");
  48 | 		const Monter = this.node.getChildByName("Monter");
  49 | 		`);
    }
  };
});
//# sourceMappingURL=7dce0d61054ef73b1a95456c859ecceef86e00e1.js.map
System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/User/Desktop/cocos_project/skeleton_animation/spine_animation/assets/singleton/ScreenManager.ts at runtime.
      throw new Error(`SyntaxError: C:\CocosDashboard_2.1.4\file:\C:\Users\User\Desktop\cocos_project\skeleton_animation\spine_animation\assets\singleton\ScreenManager.ts: Unexpected token (52:0)

  50 |     }
  51 | }
> 52 | }
     | ^
  53 |`);
    }
  };
});
//# sourceMappingURL=f4ef76c66bb9a39bbfb8c62b1c77b37d249bf234.js.map
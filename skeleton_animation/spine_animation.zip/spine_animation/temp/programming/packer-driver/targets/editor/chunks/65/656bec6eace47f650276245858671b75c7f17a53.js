System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, FullScreenManager, _crd;

  _export("FullScreenManager", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "a9e0dfivxVMYJ+KlnNdxgnZ", "FullScreen", undefined);

      _export("FullScreenManager", FullScreenManager = class FullScreenManager {
        constructor() {
          this._isFullScreen = false;
        }

        static getInstance() {
          if (this._instance === null) this._instance = new FullScreenManager();
          return this._instance;
        }

        toggleFullscreen() {
          if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().then(() => {
              this._isFullScreen = true;
            }).catch(err => {
              console.error("Error attempting to enable fullscreen mode:", err);
            });
          } else {
            document.exitFullscreen().then(() => {
              this._isFullScreen = false;
            }).catch(err => {
              console.error("Error attempting to exit fullscreen mode:", err);
            });
          }
        }

        isFullscreen() {
          return this._isFullScreen;
        }

      });

      FullScreenManager._instance = null;

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=656bec6eace47f650276245858671b75c7f17a53.js.map
System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/User/Desktop/cocos_project/skeleton_animation/spine_animation/assets/scripts/HomeController.ts at runtime.
      throw new Error(`SyntaxError: C:\CocosDashboard_2.1.4\file:\C:\Users\User\Desktop\cocos_project\skeleton_animation\spine_animation\assets\scripts\HomeController.ts: Unexpected token ','. (11:43)

   9 |         screen.on('orientation-change', this.onOrientationChange, this);
  10 |         screen.on('fullscreen-change', this.onFullScreenChange, this);
> 11 |         this.node.setRotationFromEuler(0, , 0);
     |                                            ^
  12 |       }
  13 |
  14 |       onWindowResize(width: number, height: number) {`);
    }
  };
});
//# sourceMappingURL=906ae9cfc7b72a075f391bab4e772a302be76de1.js.map
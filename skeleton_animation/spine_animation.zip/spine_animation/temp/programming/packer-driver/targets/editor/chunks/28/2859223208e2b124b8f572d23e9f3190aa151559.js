System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, FullScreenManager, _crd;

  _export("FullScreenManager", void 0);

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "4befe1jWeBAjZ+/VEKnleJC", "RotateManager", undefined);

      _export("FullScreenManager", FullScreenManager = class FullScreenManager {
        static getInstance() {
          return this._instance === null ? new FullScreenManager() : this._instance;
        }

        toggleFullScreen() {
          if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen().catch(err => {
              console.error("Error attempting to enable fullscreen mode:", err);
            });
          } else {
            document.exitFullscreen().catch(err => {
              console.error("Error attempting to exit fullscreen mode:", err);
            });
          }
        }

      });

      FullScreenManager._instance = null;

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=2859223208e2b124b8f572d23e9f3190aa151559.js.map
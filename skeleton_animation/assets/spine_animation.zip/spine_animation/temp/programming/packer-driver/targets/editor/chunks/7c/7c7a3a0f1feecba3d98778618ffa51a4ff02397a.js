System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, input, Input, KeyCode, sp, _dec, _dec2, _class, _class2, _descriptor, _crd, ccclass, property, NewComponent;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      input = _cc.input;
      Input = _cc.Input;
      KeyCode = _cc.KeyCode;
      sp = _cc.sp;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "667ccKLZaRFeaTHEfAc/ZfY", "MonterController", undefined);

      __checkObsolete__(['_decorator', 'Component', 'EventKeyboard', 'EventMouse', 'input', 'Input', 'KeyCode', 'Node', 'sp', 'SystemEvent']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("NewComponent", NewComponent = (_dec = ccclass('NewComponent'), _dec2 = property(sp.Skeleton), _dec(_class = (_class2 = class NewComponent extends Component {
        constructor(...args) {
          super(...args);

          _initializerDefineProperty(this, "spineSkeleton", _descriptor, this);
        }

        onLoad() {
          input.on(Input.EventType.KEY_DOWN, this.showAnimation, this);
          input.on(Input.EventType.MOUSE_DOWN, this.onMouseDown, this);
          this.spineSkeleton.setAnimation(0, "idle", true);
        }

        showAnimation(event) {
          if (event.keyCode === KeyCode.SPACE) {
            this.spineSkeleton.clearTrack(0);
            this.spineSkeleton.setAnimation(1, "die", false);
          } else {
            switch (event.keyCode) {
              case KeyCode.KEY_U:
                this.spineSkeleton.setAnimation(1, "attack", false);
                break;

              case KeyCode.KEY_I:
                this.spineSkeleton.setAnimation(1, "attack2", false);
                break;

              case KeyCode.KEY_O:
                this.spineSkeleton.setAnimation(1, "attack3", false);
                break;

              case KeyCode.KEY_P:
                this.spineSkeleton.setAnimation(1, "get-hit", false);
                break;
            }
          }
        }

        onMouseDown(event) {
          if (event.getButton() === 0) this.spineSkeleton.setAnimation(1, "get-hit", false);
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "spineSkeleton", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function () {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=7c7a3a0f1feecba3d98778618ffa51a4ff02397a.js.map
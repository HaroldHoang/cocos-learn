System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/User/Desktop/cocos_project/skeleton_animation/spine_animation/assets/scripts/HomeController.ts at runtime.
      throw new Error(`SyntaxError: C:\CocosDashboard_2.1.4\file:\C:\Users\User\Desktop\cocos_project\skeleton_animation\spine_animation\assets\scripts\HomeController.ts: Identifier 'Monter' has already been declared. (48:8)

  46 | 		const InstructionLabel = this.node.getChildByName("InstructionLabel");
  47 | 		const ButtonRotate = this.node.getChildByName("Monter");
> 48 | 		const Monter = this.node.getChildByName("Monter");
     | 		      ^
  49 | 		
  50 | 		if(!this.isVertical){
  51 | 			Monter.setWorldRotationFromEuler(0, 0, 90);`);
    }
  };
});
//# sourceMappingURL=d4f30ec90529b0bd3e6eea438b5b1b0a540c5a68.js.map
System.register(["cc"], function (_export, _context) {
  "use strict";

  var _cclegacy, __checkObsolete__, __checkObsoleteInNamespace__, _decorator, Component, SystemEvent, KeyCode, input, Input, dragonBones, _dec, _dec2, _class, _class2, _descriptor, _crd, ccclass, property, NezhaController;

  function _initializerDefineProperty(target, property, descriptor, context) { if (!descriptor) return; Object.defineProperty(target, property, { enumerable: descriptor.enumerable, configurable: descriptor.configurable, writable: descriptor.writable, value: descriptor.initializer ? descriptor.initializer.call(context) : void 0 }); }

  function _applyDecoratedDescriptor(target, property, decorators, descriptor, context) { var desc = {}; Object.keys(descriptor).forEach(function (key) { desc[key] = descriptor[key]; }); desc.enumerable = !!desc.enumerable; desc.configurable = !!desc.configurable; if ('value' in desc || desc.initializer) { desc.writable = true; } desc = decorators.slice().reverse().reduce(function (desc, decorator) { return decorator(target, property, desc) || desc; }, desc); if (context && desc.initializer !== void 0) { desc.value = desc.initializer ? desc.initializer.call(context) : void 0; desc.initializer = undefined; } if (desc.initializer === void 0) { Object.defineProperty(target, property, desc); desc = null; } return desc; }

  function _initializerWarningHelper(descriptor, context) { throw new Error('Decorating class property failed. Please ensure that ' + 'transform-class-properties is enabled and runs after the decorators transform.'); }

  return {
    setters: [function (_cc) {
      _cclegacy = _cc.cclegacy;
      __checkObsolete__ = _cc.__checkObsolete__;
      __checkObsoleteInNamespace__ = _cc.__checkObsoleteInNamespace__;
      _decorator = _cc._decorator;
      Component = _cc.Component;
      SystemEvent = _cc.SystemEvent;
      KeyCode = _cc.KeyCode;
      input = _cc.input;
      Input = _cc.Input;
      dragonBones = _cc.dragonBones;
    }],
    execute: function () {
      _crd = true;

      _cclegacy._RF.push({}, "af3aa2/1IxP0KDixr8VGYnS", "NezhaController", undefined);

      __checkObsolete__(['_decorator', 'Component', 'SystemEvent', 'EventKeyboard', 'KeyCode', 'input', 'Input', 'dragonBones', 'math']);

      ({
        ccclass,
        property
      } = _decorator);

      _export("NezhaController", NezhaController = (_dec = ccclass("NezhaController"), _dec2 = property(dragonBones.ArmatureDisplay), _dec(_class = (_class2 = class NezhaController extends Component {
        constructor() {
          super(...arguments);

          _initializerDefineProperty(this, "armatureDisplay", _descriptor, this);

          this.isLiving = true;
          this.keyState = {};
          this.speed = 10;
        }

        onLoad() {
          input.on(Input.EventType.KEY_DOWN, this.onKeyDown, this);
          input.on(Input.EventType.KEY_UP, this.onKeyUp, this);
        }

        onKeyDown(event) {
          this.keyState[event.keyCode] = true;

          switch (event.keyCode) {
            case KeyCode.DIGIT_1:
              this.armatureDisplay.playAnimation("attack1", 1);
              break;

            case KeyCode.DIGIT_2:
              this.armatureDisplay.playAnimation("attack1_1", 1);
              break;

            case KeyCode.DIGIT_3:
              this.armatureDisplay.playAnimation("attack1_2", 1);
              break;

            case KeyCode.DIGIT_4:
              this.armatureDisplay.playAnimation("qingzhu", 1);
              break;

            case KeyCode.DIGIT_5:
              this.armatureDisplay.playAnimation("skill1", 1);
              break;

            case KeyCode.DIGIT_6:
              this.armatureDisplay.playAnimation("dead", 1);
              break;
          }
        }

        onKeyUp(event) {
          this.keyState[event.keyCode] = false;
        }

        update() {
          if (this.isLiving) {
            this.armatureDisplay.once(dragonBones.EventObject.COMPLETE, () => {
              this.armatureDisplay.playAnimation("idle", 0);
            }, this);
            if (this.keyState[KeyCode.ARROW_RIGHT] || this.keyState[KeyCode.KEY_D]) this.moveRight();else if (this.keyState[KeyCode.ARROW_LEFT] || this.keyState[KeyCode.KEY_A]) this.moveLeft();
          }
        }

        moveRight() {
          if (this.node.getRotation().y === -180) this.node.setRotationFromEuler(0, 180, 0);
          this.armatureDisplay.playAnimation("run", 1);
          var currentPosition = this.node.getPosition();
          currentPosition.add3f(this.speed, 0, 0);
          this.node.setPosition(currentPosition);
        }

        moveLeft() {
          if (this.node.getRotation().y === 0) this.node.setRotationFromEuler(0, -180, 0);
          this.armatureDisplay.playAnimation("run", 1);
          var currentPosition = this.node.getPosition();
          currentPosition.add3f(-this.speed, 0, 0);
          this.node.setPosition(currentPosition);
        }

        onDestroy() {
          this.node.off(SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
          this.node.off(SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
        }

      }, (_descriptor = _applyDecoratedDescriptor(_class2.prototype, "armatureDisplay", [_dec2], {
        configurable: true,
        enumerable: true,
        writable: true,
        initializer: function initializer() {
          return null;
        }
      })), _class2)) || _class));

      _cclegacy._RF.pop();

      _crd = false;
    }
  };
});
//# sourceMappingURL=6b6ea4772652fff5ec8b7c6a460b4e36fceedd64.js.map
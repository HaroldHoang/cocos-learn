System.register([], function (_export, _context) {
  "use strict";

  return {
    setters: [],
    execute: function () {
      // This module is auto-generated to report error emitted when try to load module file:///C:/Users/User/Desktop/cocos_project/skeleton_animation/spine_animation/assets/scripts/HomeController.ts at runtime.
      throw new Error("SyntaxError: C:CocosDashboard_2.1.4\file:C:UsersUserDesktopcocos_projectskeleton_animationspine_animationassetsscriptsHomeController.ts: Identifier 'Monter' has already been declared. (46:8)\n\n  44 | \t\tconst Monter = this.node.getChildByName(\"Monter\");\n  45 | \t\tconst ButtonFullscreen = this.node.getChildByName(\"Monter\");\n> 46 | \t\tconst Monter = this.node.getChildByName(\"Monter\");\n     | \t\t      ^\n  47 | \t\tconst Monter = this.node.getChildByName(\"Monter\");\n  48 | \t\tconst Monter = this.node.getChildByName(\"Monter\");\n  49 | \t\t");
    }
  };
});
//# sourceMappingURL=7dce0d61054ef73b1a95456c859ecceef86e00e1.js.map
import { _decorator, Button, ButtonComponent, Component, director, Label, Node, ToggleComponent } from 'cc';
const { ccclass, property } = _decorator;

@ccclass('ButtonFullscreenController')
export class ButtonFullscreenController extends Component {
    @property(ButtonComponent)
    button: ButtonComponent | null = null;
    @property(Label)
    label: Label = null!;
    onLoad(){
       this.button.node.on(Button.EventType.CLICK, this.callback, this);
       console.log("3");
    }
    callback(button: ButtonComponent){
        if (!document.fullscreenElement) {
            this.label.string = "Exit";
            document.documentElement.requestFullscreen().catch(err => {
                console.error(err.message);
            });
        } else {
            document.exitFullscreen();
            this.label.string = "Full Screen";
        }
    }
}



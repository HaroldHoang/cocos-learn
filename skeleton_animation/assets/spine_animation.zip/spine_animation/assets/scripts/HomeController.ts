import {
    _decorator,
    Component,
    Node,
    screen,
    macro,
    ButtonComponent,
    Label,
    Button,
    view,
} from "cc";
const { ccclass, property } = _decorator;

@ccclass("HomeController")
export class HomeController extends Component {

	@property(Label)
	instructionLabel: Label = null;

	@property(Label)
	buttonFullscreenLabel: Label = null;
    private Monter;
    private ButtonFullscreen;
    private InstructionLabel;
    private ButtonRotate;
    private isVertical = false;

    onLoad() {
        this.Monter = this.node.getChildByName("Monter");
        this.ButtonFullscreen = this.node.getChildByName("ButtonFullscreen");
        this.InstructionLabel = this.node.getChildByName("InstructionLabel");
        this.ButtonRotate = this.node.getChildByName("ButtonRotate");
        this.ButtonRotate.on(Button.EventType.CLICK, this.callback, this);
		this.buttonFullscreenLabel.string = "Rotate";
    }

    callback(button: ButtonComponent) {
        if (!this.isVertical) this.showVertical();
        else this.showHorizontal();
    }
    showHorizontal() {
        this.isVertical = false;
        this.node.children.forEach((child) => {
            if (child.name != "Camera") child.setRotationFromEuler(0, 0, 0);
        });

        this.Monter.setScale(0.2, 0.2);
        this.Monter.setPosition(-20, -100);
        this.ButtonFullscreen.setPosition(560, 310, 0);
        this.ButtonRotate.setPosition(450, 310, 0);
		this.instructionLabel.string = "U: attack1      I: attack2      O: attack3      P: get-hit      Space: die\ndefault: idle";
        this.InstructionLabel.setPosition(0, -260, 0);
    }

    showVertical() {
        this.isVertical = true;
        this.node.children.forEach((child) => {
            if (child.name != "Camera") child.setRotationFromEuler(0, 0, 90);
        });

        this.Monter.setScale(0.15, 0.15);
        this.Monter.setPosition(30, -50);
        this.ButtonFullscreen.setPosition(-600, 290, 0);
        this.ButtonRotate.setPosition(-600, 170, 0);
        
		this.instructionLabel.string =
            "U: attack1       I: attack2\nO: attack3       P: get-hit        Space: die\ndefault: idle";
		this.instructionLabel.lineHeight = 60;
        this.InstructionLabel.setPosition(470, -20, 0);
    }
}
